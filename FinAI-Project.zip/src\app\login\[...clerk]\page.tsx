import { SignIn } from '@clerk/nextjs'

export default function ClerkSignIn() {
  return <SignIn />
}
